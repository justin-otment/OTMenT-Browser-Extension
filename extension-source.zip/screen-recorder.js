/**
 * screen-recorder.js
 *
 * Usage (interactive):
 *   node screen-recorder.js
 *   - Press `Enter` to toggle start/stop recording.
 *   - Type `exit` or Ctrl+C to quit.
 *
 * Usage (programmatic):
 *   const recorder = require('./screen-recorder');
 *   await recorder.startRecording('out.mp4', { fps: 25 });
 *   // ... later ...
 *   await recorder.stopRecording();
 */

const { spawn } = require('child_process');
const os = require('os');
const path = require('path');
const fs = require('fs');

let ffmpegProcess = null;
let currentOutput = null;

/**
 * Build ffmpeg args for the platform and options
 * @param {string} outputPath
 * @param {object} opts
 * @returns {Array<string>}
 */
function buildFfmpegArgs(outputPath, opts = {}) {
  const fps = opts.fps || 30;
  const crf = opts.crf || 23; // quality (lower = better)
  const preset = opts.preset || 'veryfast'; // ffmpeg encoding preset
  const maxSize = opts.video_size || null; // e.g. '1920x1080' (Linux)
  const platform = os.platform();

  // Common output options: mp4 with H.264
  const outputOpts = [
    '-y', // overwrite
    '-pix_fmt', 'yuv420p',
    '-c:v', 'libx264',
    '-preset', preset,
    '-crf', String(crf),
    '-r', String(fps),
    // '-c:a', 'aac', // audio optional - left out unless configured
    outputPath
  ];

  if (platform === 'win32') {
    // Windows: gdigrab for video. audio via dshow if user provides audioDevice
    // Example: -f gdigrab -framerate 30 -i desktop
    const videoArgs = ['-f', 'gdigrab', '-framerate', String(fps), '-i', 'desktop'];
    if (opts.audioDevice) {
      // dshow audio device name must be exact; user can find devices with ffmpeg -list_devices true -f dshow -i dummy
      return [...videoArgs, '-f', 'dshow', '-i', `audio=${opts.audioDevice}`, ...outputOpts];
    } else {
      return [...videoArgs, ...outputOpts];
    }
  } else if (platform === 'darwin') {
    // macOS: avfoundation. Format: "-f avfoundation -framerate 30 -i <screen_index>:<audio_index>"
    // In many macOS setups, the screen capture index is "1". If uncertain, try "0" or list devices: ffmpeg -f avfoundation -list_devices true -i ""
    const screenIndex = opts.screenIndex ?? '1';
    const audioIndex = opts.audioIndex ?? 'none';
    // if audioIndex is 'none' we give single input
    const input = audioIndex === 'none' ? `${screenIndex}` : `${screenIndex}:${audioIndex}`;
    return ['-f', 'avfoundation', '-framerate', String(fps), '-i', input, ...outputOpts];
  } else {
    // assume linux (x11grab)
    // require DISPLAY env var e.g. :0.0
    const display = process.env.DISPLAY || ':0.0';
    // video_size fallback
    const video_size = maxSize || (opts.width && opts.height ? `${opts.width}x${opts.height}` : null);
    const base = ['-f', 'x11grab', '-framerate', String(fps)];
    if (video_size) base.push('-video_size', video_size);
    base.push('-i', `${display}+${opts.offsetX || 0},${opts.offsetY || 0}`);
    if (opts.audioDevice) {
      // Linux audio capture is system-dependent; user may use pulse or alsa device
      // Example for pulse: -f pulse -i default
      base.push('-f', opts.audioFormat || 'pulse', '-i', opts.audioDevice);
    }
    return [...base, ...outputOpts];
  }
}

/**
 * Start recording to the given output path.
 * Resolves when ffmpeg process is started.
 * Rejects if already recording or ffmpeg not found.
 *
 * @param {string} outputPath
 * @param {object} opts
 * @returns {Promise<void>}
 */
function startRecording(outputPath = null, opts = {}) {
  return new Promise((resolve, reject) => {
    if (ffmpegProcess) {
      return reject(new Error('Already recording'));
    }

    if (!outputPath) {
      const ts = new Date().toISOString().replace(/[:.]/g, '-');
      outputPath = path.resolve(process.cwd(), `screen-record-${ts}.mp4`);
    } else {
      outputPath = path.resolve(process.cwd(), outputPath);
    }

    // Ensure output folder exists
    const outDir = path.dirname(outputPath);
    if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

    // Build args
    const args = buildFfmpegArgs(outputPath, opts);

    // Spawn ffmpeg
    const proc = spawn('ffmpeg', args, { stdio: ['ignore', 'pipe', 'pipe'] });

    proc.on('error', (err) => {
      ffmpegProcess = null;
      reject(new Error(`Failed to start ffmpeg. Ensure ffmpeg is installed and on PATH. (${err.message})`));
    });

    // Forward stderr (ffmpeg logs) to console
    proc.stderr.on('data', (d) => {
      // Silence or parse if you want; show minimal info
      process.stderr.write(d);
    });

    proc.stdout.on('data', (d) => {
      process.stdout.write(d);
    });

    proc.on('exit', (code, signal) => {
      // ffmpeg exited
      console.log(`ffmpeg exited with code=${code} signal=${signal}`);
      ffmpegProcess = null;
      currentOutput = null;
    });

    ffmpegProcess = proc;
    currentOutput = outputPath;

    // give the process a short chance to error out (e.g., invalid device)
    setTimeout(() => {
      if (!ffmpegProcess) {
        return reject(new Error('ffmpeg failed immediately; check console for details'));
      }
      console.log(`Recording started -> ${outputPath}`);
      resolve();
    }, 300);
  });
}

/**
 * Stop current recording. Resolves when process exits.
 * @returns {Promise<void>}
 */
function stopRecording() {
  return new Promise((resolve, reject) => {
    if (!ffmpegProcess) return resolve();

    // ffmpeg gracefully stops when it receives 'q' on stdin or SIGINT.
    // We try sending 'q' first for a clean finalize; fallback to SIGINT, then SIGTERM.
    try {
      ffmpegProcess.stdin && ffmpegProcess.stdin.write('q');
    } catch (e) {
      // ignore
    }

    // wait up to some seconds for exit
    const timeoutMs = 5000;
    let done = false;

    const onExit = () => {
      if (done) return;
      done = true;
      ffmpegProcess = null;
      const out = currentOutput;
      currentOutput = null;
      console.log(`Recording stopped. Saved to ${out}`);
      resolve();
    };

    ffmpegProcess.once('exit', onExit);

    // fallback: after delay, try SIGINT -> SIGTERM
    setTimeout(() => {
      if (done) return;
      try {
        ffmpegProcess.kill('SIGINT');
      } catch (e) {}
    }, 1200);

    setTimeout(() => {
      if (done) return;
      try {
        ffmpegProcess.kill('SIGTERM');
      } catch (e) {}
    }, timeoutMs);

    // final fallback: kill and resolve after a short delay
    setTimeout(() => {
      if (done) return;
      try {
        ffmpegProcess.kill('SIGKILL');
      } catch (e) {}
      done = true;
      ffmpegProcess = null;
      const out = currentOutput;
      currentOutput = null;
      resolve();
    }, timeoutMs + 1500);
  });
}

// Expose programmatic API
module.exports = {
  startRecording,
  stopRecording,
  isRecording: () => !!ffmpegProcess,
  getCurrentOutput: () => currentOutput,
};

// If run directly, provide a small interactive CLI
if (require.main === module) {
  const readline = require('readline');
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

  console.log('Screen recorder CLI');
  console.log('Press Enter to toggle start/stop recording. Type "exit" to quit.');

  rl.on('line', async (line) => {
    const trimmed = line.trim();
    if (trimmed === 'exit') {
      if (module.exports.isRecording()) {
        await module.exports.stopRecording();
      }
      rl.close();
      process.exit(0);
    }

    if (!module.exports.isRecording()) {
      // optional: ask for filename or use default
      const name = `record-${Date.now()}.mp4`;
      try {
        await module.exports.startRecording(name, { fps: 30 });
      } catch (err) {
        console.error('Failed to start recording:', err.message);
      }
    } else {
      await module.exports.stopRecording();
    }
  });

  // cleanup on signals
  process.on('SIGINT', async () => {
    console.log('\nSIGINT received. Stopping recording (if any) and exiting...');
    try { await module.exports.stopRecording(); } catch(e) {}
    process.exit(0);
  });
}
